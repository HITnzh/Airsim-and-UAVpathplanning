import matplotlib.pyplot as plt

import math
import numpy as np


def distance(A, B):
    return math.sqrt((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2)


def myatan(A, B):
    x1, y1, x2, y2 = A[0], A[1], B[0], B[1]
    if x1 != x2:
        if x1 > x2:
            return math.atan((y1 - y2) / (x1 - x2)) + math.pi
        else:
            return math.atan((y1 - y2) / (x1 - x2))
    if x1 == x2 and y1 == y2:
        return None
    if x1 == x2 and y1 != y2:
        if y1 > y2:
            return -math.pi / 2
        else:
            return math.pi / 2


def move_by_path(P, Va, psi, Path, delta, K, K2, dt=0.01):
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams["axes.unicode_minus"] = False
    [Px, Py] = P
    # Wb = P
    pos_record = [[Px, Py]]
    aim_record = []
    for i in range(1, len(Path)):
        Wa = Path[i - 1]
        Wb = Path[i]
        theta = myatan(Wa, Wb)
        while True:
            theta_u = myatan(Wa, [Px, Py])
            if theta_u is None:
                theta_u = theta
            beta = theta - theta_u
            Ru = distance(Wa, [Px, Py])
            R = Ru * math.cos(beta)
            e = Ru * math.sin(beta)
            print(Px, Py, e)
            xt = Wa[0] + (R + delta) * math.cos(theta)
            yt = Wa[1] + (R + delta) * math.sin(theta)
            if (xt - Wb[0]) * (Wb[0] - Wa[0]) > 0 \
                    or (yt - Wb[1]) * (Wb[1] - Wa[1]) > 0:
                break
            psi_d = myatan([Px, Py], [xt, yt])
            u = K * (psi_d - psi) * Va + K2 * e
            if u > 1:  # 限制u的范围
                u = 1
            psi = psi_d
            Vy = Va * math.sin(psi) + u * dt
            if abs(Vy) >= Va:
                Vy = Va
                Vx = 0
            else:
                Vx = np.sign(math.cos(psi)) * math.sqrt(Va ** 2 - Vy ** 2)
            Px = Px + Vx * dt
            Py = Py + Vy * dt
            pos_record.append([Px, Py])
            aim_record.append([xt, yt])
    # 点采样和绘图
    pos_plot = []
    aim_plot = []
    num = 25
    gap = int(len(pos_record) / num)
    for i in range(num):
        pos_plot.append(pos_record[i * gap])
        aim_plot.append(aim_record[i * gap])
    pos_plot = np.array(pos_plot).T
    aim_plot = np.array(aim_plot).T
    route = np.array(Path).T
    plt.plot(route[0], route[1])
    plt.plot(pos_plot[0], pos_plot[1], '--')
    plt.plot(aim_plot[0], aim_plot[1], '*')
    plt.legend(['目标轨迹', '实际轨迹', '目标航点'])
    plt.axis('equal')
    plt.grid()
    plt.show()


if __name__ == "__main__":
    path = [[0, 0], [10, 15], [15, 20], [20, 5]]
    move_by_path([10, 3], 3, 0.5, path, delta=1, K=15, K2=0)
    # move_to_point([3, 3], 3, 0, [0, 0], [10, 15])