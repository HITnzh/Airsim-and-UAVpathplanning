from ctypes import c_int

import airsim



# 初始化，建立连接
client = airsim.MultirotorClient()  # 创建连接
client.confirmConnection()  # 检查连接
client.reset()
client.enableApiControl(True)  # 获取控制权
client.armDisarm(True)  # 电机启转
client.takeoffAsync().join()  # 起飞

waypoints = [
    airsim.Vector3r(0,0,-3),
    airsim.Vector3r(10, 7, -5),
    airsim.Vector3r(20, 14, -1),
    airsim.Vector3r(30, 0, -2),
    airsim.Vector3r(40, 4, -4),
    airsim.Vector3r(50, 8, -3),
]
#client.moveToZAsync(-3, 1).join()  # 上升到3米高度
#client.simSetTraceLine([1, 0, 0, 1], thickness=5)
#client.simFlushPersistentMarkers()  # 清空画图

# 初始化4个点的坐标，并在视口中标识出来
#points = [airsim.Vector3r(5, 0, -3),
#airsim.Vector3r(5, 5, -3),
#airsim.Vector3r(0, 5, -3),
#airsim.Vector3r(0, 0, -3)]

client.simPlotPoints(waypoints, color_rgba=[0, 1, 0, 1], size=30, is_persistent=True)

flown_path = []
client.moveOnPathAsync(path=waypoints,velocity=5,lookahead=3).join()
for waypoint in waypoints:
    #client.moveToPositionAsync(waypoint.x_val,waypoint.y_val,waypoint.z_val,velocity=2).join()
    current_position = client.getMultirotorState().kinematics_estimated.position
    flown_path.append(current_position)
   # client.simPlotLineStrip(flown_path,color_rgba=[1,0,0,1],thickness=5,is_persistent=True)
    client.simPlotLineStrip(
        waypoints,
        color_rgba=[1.0, 0.0, 0.0, 1.0],
        thickness=1.0,
        duration=-1.0,
        is_persistent=False,
    )
# 仿真结束
client.goHomeAsync().join()  # 返航
client.landAsync().join()  # 降落
client.armDisarm(False)  # 电机上锁
client.enableApiControl(False)  # 释放控制权